DAC stands for "Dynamic Access Control."

DAC is an access control technology similar to NTFS permissions
first introduced with Server 2012.  SEC505 used to have a long
module on DAC, but I deleted it after Microsoft more-or-less
abandoned DAC as part of its larger movement towards Azure and 
Office 365.  The scripts for the DAC labs are still here though,
just be aware that Microsoft may officially deprecate DAC soon. 


