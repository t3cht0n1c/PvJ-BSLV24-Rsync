This folder contains a PowerShell script to reset the password of
the krbtgt account in Active Directory when that account has been
compromised, perhaps for use in a Golden Ticket attack.

To obtain the latest version of the script, see:

   https://gallery.technet.microsoft.com/Reset-the-krbtgt-account-581a9e51/view/Discussions

   http://microsoft.com/pth


