﻿#.DESCRIPTION
#  Creates/deletes files for the protect lab.
#.PARAMETER DeleteInstead
#  Deletes the *.cms, *.tiff and *.btu files.


Param ( $ComputerName = $env:COMPUTERNAME, 
        $TargetUser = $env:USERNAME,
        $SourceFile = "C:\SANS\Day6\Protect\MimiCat.tiff",
        [Int] $FileCountPerFolder = 3,
        [Switch] $DeleteInstead ) 


$ProfilePath = "\\$ComputerName\C$\Users\$TargetUser"


if (-not (Test-Path -Path $SourceFile))
{
    $SourceFile = "C:\SANS\Day6\Protect\Backups\MimiCat.tiff"
}


if ((-not $DeleteInstead) -and -not (Test-Path -Path $SourceFile))
{
    Throw ("ERROR: Cannot find " + $SourceFile)
    Exit
}


if ( -not (Test-Path -Path $ProfilePath))
{
    Throw ("ERROR: Cannot access " + $ProfilePath )
    Exit
}


function RandomFileName
{ 
    $Name = Get-Random -InputObject `
               @("Charts","IncomeStatement","FiscalPlans",
               "SourceCode","PhoneDirectory","SatelliteImagery",
               "ContractSig","NDAform","TacoCat","MedicalStd",
               "Widgettes","LegalBrief","VincentGordon",
               "CPBroster","Warrant","MarketThai","EternalBlue",
               "BlackHills","RouterConfig","Sec505","GCWN",
               "Telemetry","NEXUS","KnivesChau","33","Metric")

    $Name = $Name + ( Get-Random -Minimum 1 -Maximum 9 ) 
    
    $Name + (Get-Random -InputObject @(".btu",".tiff"))
}


if ($DeleteInstead)
{
    ForEach ($Folder in @("Desktop","Documents","Pictures"))
    {
        $SubDir = Join-Path -Path $ProfilePath -ChildPath $Folder
        Remove-Item -Recurse -Path $SubDir -Include *.cms,*.tiff,*.btu 
        Remove-Item -Path (Join-Path -Path $SubDir -ChildPath "README_NOW_YOUR_FILES_ARE_ENCRYPTED.txt") -ErrorAction SilentlyContinue
    }

    Remove-Item -Path C:\Users\Public\Desktop\README_NOW_YOUR_FILES_ARE_ENCRYPTED.txt -ErrorAction SilentlyContinue
}
else
{
    ForEach ($Folder in @("Desktop","Documents","Pictures"))
    {
        1..($FileCountPerFolder) | ForEach `
        {
            $NewFile = Join-Path -Path $ProfilePath -ChildPath $Folder
            $NewFile = Join-Path -Path $NewFile -ChildPath (RandomFileName)
            Copy-Item -Path $SourceFile -Destination $NewFile -Verbose
        }
    }
}

