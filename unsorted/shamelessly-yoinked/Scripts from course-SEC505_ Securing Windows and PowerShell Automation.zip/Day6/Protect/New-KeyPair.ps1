﻿###########################################################################
#.SYNOPSIS
# Demo how to create a self-signed certificate and private key.
#
#.DESCRIPTION
# Creates a self-signed certifiate with a private key, then 1) exports the
# certificate to a DER-encoded CER file and 2) exports the private key to 
# a PKCS#12 PFX file with a hard-coded password.  Careful!  If you run the
# script multiple times with the same arguments, existing CER and PFX files
# will be overwritten!
#
#.NOTES
# The DataEncipherment key usage and the DocumentEncryptionCert type 
# are needed for Microsoft's Protect-CmsMessage cmdlet.  See the help
# for the New-SelfSignedCertificate cmdlet for the many other options.  
###########################################################################

Param ( $PublicKeyCertificateFilePath = "$PWD\PublicKey.cer",
        $PrivateKeyFilePath = "$PWD\PrivateKey.pfx",
        $EncryptionPassword = "P@ssword" )


# Create a hashtable of parameters and arguments for splatting:
$Splat = @{ CertStoreLocation = "Cert:\CurrentUser\My"  
            DnsName = "PROTECT MY FILES" 
            NotAfter = (Get-Date).AddYears(20) 
            KeyUsage = "DataEncipherment" 
            Type = "DocumentEncryptionCert" 
            KeyAlgorithm = "RSA" 
            KeyLength = 2048 
            HashAlgorithm = "SHA256" 
            Provider = "Microsoft Enhanced Cryptographic Provider v1.0" }


# Create self-signed certificate with its associated private key.  This 
# will also import the certificate and private key into the local profile 
# of the user who is running this script:
$Cert = New-SelfSignedCertificate @Splat


# Note: If you do a refresh, you can now see this new cert in your Certificates MMC
# snap-in and in your PowerShell certificate drive: dir Cert:\CurrentUser\My\


# Export the certificate to a CER file, but not the private key:
Export-Certificate -Cert ("Cert:\CurrentUser\My\" + $Cert.Thumbprint) -FilePath $PublicKeyCertificateFilePath


# Password to encrypt the exported private key:
$pw = ConvertTo-SecureString -String $EncryptionPassword -Force -AsPlainText


# Export the private key to the PFX file:
Export-PfxCertificate -Cert ("Cert:\CurrentUser\My\" + $Cert.Thumbprint) -Password $pw -FilePath $PrivateKeyFilePath


# Note that the PFX file has both the private key and the public
# key certificate inside it, not just the private key.

# FIN