Not required, but you can place any required resources
here, such as MSI packages to be installed.