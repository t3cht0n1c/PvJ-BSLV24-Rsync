﻿
#$Top.Request = "Stop" 

"Hello World!"

#Get-Service -Name NoSuchService -ErrorAction Stop

#$Top.Request = "Continue"
