﻿"Hello World!"

# Throw an error:
#Throw "The Exception Ball"

# Make an illegal request:
#$Top.Request = "format.exe C:\"

# Remove the Request key from $Top:
#$Top.Remove('Request')
